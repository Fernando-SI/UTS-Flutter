import 'package:flutter/material.dart';
import 'package:uts/home.dart';

void main() {
  runApp(Nans());
}

class Nans extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Home(),
    );
  }
}