class Villa {
  final String name;
  final String imagePath;
  final double rating;

  Villa({
    required this.name,
    required this.imagePath,
    required this.rating,
  });
}

final List<Villa> villas = [
  Villa(name: 'Fortune Villa', imagePath: 'assets/hotel.png', rating: 4.7),
  Villa(name: 'Ghistha Villa', imagePath: 'assets/hotel2.jpg', rating: 4.4),
  Villa(name: 'Hesmionu Villa', imagePath: 'assets/hotel3.jpg', rating: 4.8),
  Villa(name: 'Ivy Villa', imagePath: 'assets/hotel4.jpg', rating: 4.5),
  Villa(name: 'Jevon Villa', imagePath: 'assets/hotel5.jpg', rating: 4.9),
];
