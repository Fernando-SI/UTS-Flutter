// hotel.dart

class Hotel {
  final String name;
  final String imagePath;
  final double rating;

  Hotel({
    required this.name,
    required this.imagePath,
    required this.rating,
  });
}

final List<Hotel> hotels = [
  Hotel(name: 'Lotus Hotel', imagePath: 'assets/hotel6.jpg', rating: 4.8),
  Hotel(name: 'Ansquilla Hotel', imagePath: 'assets/hotel7.jpeg', rating: 4.5),
  Hotel(name: 'Anestich Hotel', imagePath: 'assets/hotel8.jpg', rating: 4.9),
  Hotel(name: 'Brovica Hotel', imagePath: 'assets/hotel9.jpeg', rating: 4.3),
  Hotel(name: 'Sumprieaso Hotel', imagePath: 'assets/hotel10.jpeg', rating: 4.6),
];
