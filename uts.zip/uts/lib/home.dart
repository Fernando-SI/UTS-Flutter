import 'package:flutter/material.dart';
import 'hotel.dart'; // Pastikan file hotel.dart ada di direktori yang sama atau sesuaikan path-nya
import 'villa.dart'; // Pastikan file villa.dart ada di direktori yang sama atau sesuaikan path-nya

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(kToolbarHeight),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [const Color.fromARGB(255, 102, 75, 69), const Color.fromARGB(255, 166, 140, 130)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: AppBar(
            title: Text('StayApps', style: TextStyle(color: Colors.white)),
            centerTitle: true,
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: IconButton(
              icon: Icon(Icons.menu, color: Colors.white),
              onPressed: () {},
            ),
            actions: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: GestureDetector(
                    onTap: () => _showProfileDialog(context),
                    child: CircleAvatar(
                      backgroundImage: AssetImage('assets/profile.jpg'), // Ganti dengan path gambar profil Anda
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.brown.shade100, Colors.white],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Banner
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: LinearGradient(
                      colors: [Colors.brown, Colors.greenAccent],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Special Discount\nfor June',
                        style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 10),
                      Row(
                        children: [
                          Spacer(),
                            ElevatedButton(
                            onPressed: () {},
                            style: ElevatedButton.styleFrom(backgroundColor: Color.fromARGB(255, 154, 116, 116)),
                            child: Text('Stay Now', style: TextStyle(color: const Color.fromARGB(255, 255, 255, 255))),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
                SizedBox(height: 20),
                // Search Bar
                TextField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    hintText: 'Look for a place to stay',
                    prefixIcon: Icon(Icons.search),
                  ),
                ),
                SizedBox(height: 20),
                // Hotels
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Hotels', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    TextButton(onPressed: () {}, child: Text('See all')),
                  ],
                ),
                SizedBox(height: 10),
                // Hotel List
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: List.generate(hotels.length, (index) => hotelCard(hotels[index])),
                  ),
                ),
                SizedBox(height: 30), // Tambahkan jarak antara bagian hotel dan villa
                // Villas
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Villas', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    TextButton(onPressed: () {}, child: Text('See all')),
                  ],
                ),

                SizedBox(height: 10),
                // Villa List
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: List.generate(villas.length, (index) => villaCard(villas[index])),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Search'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_cart), label: 'Cart'),
        ],
      ),
    );
  }

  void _showProfileDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: GestureDetector(
            onTap: () {
              Navigator.of(context).pop();
            },
            child: Container(
              width: MediaQuery.of(context).size.width * 0.8,
              height: MediaQuery.of(context).size.width * 0.8,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/profile.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget hotelCard(Hotel hotel) {
    return Container(
      margin: EdgeInsets.only(right: 10),
      width: 150,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 100,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              image: DecorationImage(
                image: AssetImage(hotel.imagePath), // Menggunakan path gambar dari objek hotel
                fit: BoxFit.cover,
              ),
            ),
          ),
          SizedBox(height: 5),
          Text(hotel.name, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
          Row(
            children: [
              Icon(Icons.star, color: Colors.orange, size: 14),
              Text(hotel.rating.toString(), style: TextStyle(fontSize: 12)),
            ],
          ),
        ],
      ),
    );
  }

  Widget villaCard(Villa villa) {
    return Container(
      margin: EdgeInsets.only(right: 10),
      width: 150,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 100,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              image: DecorationImage(
                image: AssetImage(villa.imagePath), // Menggunakan path gambar dari objek villa
                fit: BoxFit.cover,
              ),
            ),
          ),
          SizedBox(height: 5),
          Text(villa.name, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
          Row(
            children: [
              Icon(Icons.star, color: Colors.orange, size: 14),
              Text(villa.rating.toString(), style: TextStyle(fontSize: 12)),
            ],
          ),
        ],
      ),
    );
  }
}
